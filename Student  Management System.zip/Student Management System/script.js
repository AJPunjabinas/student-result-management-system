// Signup
function signup() {
  const email = document.getElementById("signupEmail").value;
  const password = document.getElementById("signupPassword").value;

  if (!email || !password) {
    alert("Fill all fields");
    return;
  }

  localStorage.setItem("user", JSON.stringify({ email, password }));
  alert("Signup successful");
  window.location.href = "index.html";
}

// Login
function login() {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;
  const user = JSON.parse(localStorage.getItem("user"));

  if (user && email === user.email && password === user.password) {
    alert("Login successful");
    window.location.href = "dashboard.html";
  } else {
    alert("Invalid credentials");
  }
}

// Logout
function logout() {
  window.location.href = "index.html";
}

// Add Student
function addStudent() {
  const name = document.getElementById("studentName").value;
  const roll = document.getElementById("studentRoll").value;

  if (!name || !roll) {
    alert("Please fill all fields");
    return;
  }

  const students = JSON.parse(localStorage.getItem("students")) || [];
  students.push({ name, roll });
  localStorage.setItem("students", JSON.stringify(students));
  renderTable();
  document.getElementById("studentName").value = '';
  document.getElementById("studentRoll").value = '';
}

// Delete Student
function deleteStudent(index) {
  const students = JSON.parse(localStorage.getItem("students")) || [];
  students.splice(index, 1);
  localStorage.setItem("students", JSON.stringify(students));
  renderTable();
}

// Edit Student
function editStudent(index) {
  const students = JSON.parse(localStorage.getItem("students")) || [];
  const student = students[index];
  const newName = prompt("Enter new name", student.name);
  const newRoll = prompt("Enter new roll no.", student.roll);
  if (newName && newRoll) {
    students[index] = { name: newName, roll: newRoll };
    localStorage.setItem("students", JSON.stringify(students));
    renderTable();
  }
}

// Search
function searchStudent() {
  const filter = document.getElementById("searchInput").value.toLowerCase();
  const rows = document.querySelectorAll("#studentTable tbody tr");
  rows.forEach(row => {
    const name = row.children[0].textContent.toLowerCase();
    const roll = row.children[1].textContent.toLowerCase();
    row.style.display = name.includes(filter) || roll.includes(filter) ? "" : "none";
  });
}

// Display Table
function renderTable() {
  const students = JSON.parse(localStorage.getItem("students")) || [];
  const tbody = document.querySelector("#studentTable tbody");
  tbody.innerHTML = "";
  students.forEach((student, index) => {
    const row = `<tr>
      <td>${student.name}</td>
      <td>${student.roll}</td>
      <td>
        <button onclick="editStudent(${index})">Edit</button>
        <button onclick="deleteStudent(${index})">Delete</button>
      </td>
    </tr>`;
    tbody.innerHTML += row;
  });
}

// Run only on dashboard page
if (window.location.pathname.includes("dashboard.html")) {
  renderTable();
}
